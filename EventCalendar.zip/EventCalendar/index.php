<?php
	session_start();
	include "dbconn.php";
	
	if(isset($_POST['singlebutton']))
	{
		$startdate = $_POST['startdate'];
		$myArray = explode(' ',$startdate);
		$dup = explode('-',$myArray[0]);
		$m = date("m",strtotime($dup[1]));
		$dt1=$dup[2]."-".$m."-".$dup[0]." ".$myArray[1];
		$today = Date('Y-m-d H:i:s');
		
		$enddate = $_POST['enddate'];
		$myArray1 = explode(' ',$enddate);
		$dup1 = explode('-',$myArray1[0]);
		$m1 = date("m",strtotime($dup1[1]));
		$dt2=$dup1[2]."-".$m1."-".$dup1[0]." ".$myArray1[1];
		
		$meetingtype = $_POST['meetingtype'];		
		$project = $_POST['project'];
		$du = $_POST['du'];
		$vcr = $_POST['vcr'];
		$requestedby = $_POST['requestedby'];
		$requestedon = date('Y-m-d H:i:s');
		//echo "SELECT * FROM tblactivities WHERE START BETWEEN '$dt1' AND '$dt2' OR END BETWEEN '$dt1' AND '$dt2'";
		$select_list = mysqli_query($connect,"SELECT * FROM tblactivities WHERE START BETWEEN '$dt1' AND '$dt2' OR END BETWEEN '$dt1' AND '$dt2'");
		$booked_list = mysqli_fetch_array($select_list);
		//echo $booked_list['title']."Name";
			if($booked_list[0]){
				echo "<script type='text/javascript'>alert('Already Booked Or Incorrect Selection.Please Check list and Choose different Date and Time.');</script>";
			}else{
				if($dt1 > $today && $dt1 < $dt2){
					$insert=mysqli_query($connect,"insert into tblactivities (title,start,end,act_project,act_du,act_vcr,act_req_by,act_req_on,act_upd_by,act_upd_on,status) values('$meetingtype','$dt1','$dt2','$project','$du','$vcr','$requestedby','$requestedon',null,null,1)");
					if($insert){
						echo "<script type='text/javascript'>alert('Booked');</script>";
					}
				}
			}
	}
?>
<!DOCTYPE html>
<!-- 
Template Name: Metronic - Responsive Admin Dashboard Template build with Twitter Bootstrap 3.3.7
Version: 4.7.1
Author: KeenThemes
Website: http://www.keenthemes.com/
Contact: support@keenthemes.com
Follow: www.twitter.com/keenthemes
Dribbble: www.dribbble.com/keenthemes
Like: www.facebook.com/keenthemes
Purchase: http://themeforest.net/item/metronic-responsive-admin-dashboard-template/4021469?ref=keenthemes
Renew Support: http://themeforest.net/item/metronic-responsive-admin-dashboard-template/4021469?ref=keenthemes
License: You must have a valid license purchased only from themeforest(the above link) in order to legally use the theme for your project.
-->
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">
<style>

	body {
		margin: 40px 10px;
		padding: 0;
		font-family: "Lucida Grande",Helvetica,Arial,Verdana,sans-serif;
		font-size: 14px;
	}

	#calendar {
		max-width: 900px;
		margin: 0 auto;
	}
	.request{
		 margin: auto;
		width: 50%;
		border: 2px solid #386077;
		padding: 10px;
	}

	.tbl-border{
		 margin: auto;
		width: 95%;
		border: 2px solid #386077;
		padding: 10px;
	}
	.fc-day-grid-event > .fc-content {
		white-space: normal !important;
	}
</style>

	<?php include 'header.php'; ?>
    <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">
        <div class="page-wrapper">
            <!-- BEGIN HEADER -->
            <?php //include "header.php"; ?>
            <!-- BEGIN HEADER & CONTENT DIVIDER -->
            <div class="clearfix"> </div>
            <!-- END HEADER & CONTENT DIVIDER -->
            <!-- BEGIN CONTAINER -->
            <div class="page-container">
                
                <!-- BEGIN CONTENT -->
                    <div class="page-content-wrapper">
                    <!-- BEGIN CONTENT BODY -->
                    <div class="page-content tbl-border">
                        <div class="container-fluid">
							<div class="portlet light portlet-fit bordered calendar">
							   
								<div class="portlet-body" style="padding-top:50px;">
									<div class="row">
									
										 <div class="col-lg-7">
												<div id='calendar'></div>
										</div>
										
											<div class="col-lg-4 request" style="padding-left:10px;" style="padding-buttom:20% !important;">
												<center><h2 style="color:#386077;"><b>Create Request</b></h2></center><br>
											<form action="" method="POST" name="book_form" class="form-horizontal">
												<div class="form-group row">
													<label for="colFormLabel" class="col-sm-4 col-form-label">Start Date</label>
													<div class="col-sm-8">
													  <input id="demo3" type="text" name="startdate" size="25" required=""><a href="javascript:NewCal('demo3','ddmmmyyyy',true,24)"><img src="cal.gif" width="16" height="16" border="0" alt="Pick a date"></a><span style='font-size:13px;'>Note: Select proper Date and Time</span>
													</div>
												</div>
												<div class="form-group row">
													<label for="colFormLabel" class="col-sm-4 col-form-label">End Date</label>
													<div class="col-sm-8">
													  <input id="demo4" name="enddate" type="text" name="startdate" size="25" required=""><a href="javascript:NewCal('demo4','ddmmmyyyy',true,24)"><img src="cal.gif" width="16" height="16" border="0" alt="Pick a date"></a><span style='font-size:13px;'>Note: Select proper Date and Time</span>
													</div>
												</div>
												<div class="form-group row">
													<label for="colFormLabel" class="col-sm-4 col-form-label">Meeting Type</label>
													<div class="col-sm-8">
													  <input id="meetingtype" name="meetingtype" type="text" placeholder="Meeting Type" class="form-control input-md" required="">
													</div>
												</div>
												<div class="form-group row">
													<label for="colFormLabel" class="col-sm-4 col-form-label">Project</label>
													<div class="col-sm-8">
													  <input id="project" name="project" type="text" placeholder="Project" class="form-control input-md" required="">
													</div>
												</div>
												<div class="form-group row">
													<label for="colFormLabel" class="col-sm-4 col-form-label">DU</label>
													<div class="col-sm-8">
													  <input id="du" name="du" type="text" placeholder="DU" class="form-control input-md" required="">
													</div>
												</div>
												<div class="form-group row">
													<label for="colFormLabel" class="col-sm-4 col-form-label">VC Required</label>
													<div class="col-sm-8" required>
													  <div class="custom-control custom-radio custom-control-inline">
														  <input type="radio" id="customRadioInline1" name="vcr" value="YES" class="custom-control-input">
														  <label class="custom-control-label" for="customRadioInline1">YES</label>
														</div>
														<div class="custom-control custom-radio custom-control-inline">
														  <input type="radio" id="customRadioInline2" name="vcr" value="NO" class="custom-control-input">
														  <label class="custom-control-label" for="customRadioInline2">NO</label>
														</div>
													</div>
												</div>
												
												<div class="form-group row">
													<label for="colFormLabel" class="col-sm-4 col-form-label">Requested By</label>
													<div class="col-sm-8">
													  <input id="requestedby" name="requestedby" type="text" placeholder="Requested By" class="form-control input-md" required="">
													</div>
												</div>
													<div class="form-group">
													  <center>
													  <div class="col-md-4">
														<input type="submit" id="singlebutton" name="singlebutton" class="btn btn-primary btn-large" value="Add Event">
													  </div></center>
													</div>
											
											</form>
											</div>
										</div>
									</div>
								</div>
                                </div>
                            </div>
                        </div>
                                       
                 
                    </div>
                    <!-- END CONTENT BODY -->
                </div>
             <!-- END CONTENT -->
                <!-- BEGIN QUICK SIDEBAR -->
                <a href="javascript:;" class="page-quick-sidebar-toggler">
                    <i class="icon-login"></i>
                </a>
                
                <!-- END QUICK SIDEBAR -->
            </div>
            <!-- END CONTAINER -->
            <!-- BEGIN FOOTER -->
            <?php //include "footer.php"; ?>
            <!-- END FOOTER -->
        </div>
        <!-- BEGIN QUICK NAV -->
        <!-- END QUICK NAV -->
        <?php //include "foot.php"; ?>
		<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
		
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
        <script src='datetimepicker.js'></script>
        <script src='fullcalendar/lib/moment.min.js'></script>
        <script src='fullcalendar/lib/jquery.min.js'></script>
		<script src='fullcalendar/fullcalendar.min.js'></script>
			<script type="text/javascript" src="//cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
  <script type="text/javascript" src="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.js"></script>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/qtip2/3.0.3/basic/jquery.qtip.min.js"></script>
  
  
        <script>
			$(document).ready(function() {
				$('#calendar').fullCalendar({

					<!--Header Section Including Previous,Next and Today-->
					header: {
					left: 'prev,next today',
					center: 'title',
					right: 'month,agendaWeek,agendaDay,listWeek'
					},

					<!--Default Date-->
					timeFormat: 'H:mm',
					eventColor: '#6ebdea',
					displayEventEnd: true,
					defaultDate: new Date(),
					events: {url : 'eventsdata.php'}
				});
		});

		</script>
		
    </body>

</html>