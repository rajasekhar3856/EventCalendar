<?php
error_reporting(0);
include 'dbconn.php';
$simselectlist = mysqli_query($connect,"select * from tblactivities");
$now = date('Y-m-d H:i:s');
while($simgetlist = mysqli_fetch_array($simselectlist)){
	if($now < $simgetlist['start']){
		$update = mysqli_query($connect,"update tblactivities set status = 1 where id=".$simgetlist['id']);
	}elseif($now > $simgetlist['end']){
		$update = mysqli_query($connect,"update tblactivities set status = 3 where id=".$simgetlist['id']);
	}else{
		$update = mysqli_query($connect,"update tblactivities set status = 2 where id=".$simgetlist['id']);
	}
}

?>
<!DOCTYPE html>
<!-- 
Template Name: Metronic - Responsive Admin Dashboard Template build with Twitter Bootstrap 3.3.7
Version: 4.7.1
Author: KeenThemes
Website: http://www.keenthemes.com/
Contact: support@keenthemes.com
Follow: www.twitter.com/keenthemes
Dribbble: www.dribbble.com/keenthemes
Like: www.facebook.com/keenthemes
Purchase: http://themeforest.net/item/metronic-responsive-admin-dashboard-template/4021469?ref=keenthemes
Renew Support: http://themeforest.net/item/metronic-responsive-admin-dashboard-template/4021469?ref=keenthemes
License: You must have a valid license purchased only from themeforest(the above link) in order to legally use the theme for your project.
-->
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="en">

	<?php include 'header.php'; ?>
	<style>
		.tbl-border{
			 margin: auto;
			width: 95%;
			border: 2px solid #386077;
			padding: 10px;
		}
		
	</style>
    <body class="page-header-fixed page-sidebar-closed-hide-logo page-content-white">
	<div class="tbl-border"  style="padding-left:100px;">
       <div class='container-fluid'  style="padding-top:50px;padding-left:100px;">
			<div class='col-lg-2'></div>
			<div class='col-lg-10'>
				<form method='POST' name='listform'>
				  <div class="form-row align-items-center">
					<div class="col-auto">
					  <label class="sr-only" for="inlineFormInputGroup">Username</label>
					  <div class="input-group mb-2">
						<div class="input-group-prepend">
						  <div class="input-group-text">Start Date</div>
						</div>
						<input id="demo3" type="text" name="startdate" size="25"><a href="javascript:NewCal('demo3','ddmmmyyyy',true,24)"><img src="cal.gif" width="16" height="16" border="0" alt="Pick a date"></a>
					  </div>
					</div>
					<div class="col-auto">
					  <label class="sr-only" for="inlineFormInputGroup">Username</label>
					  <div class="input-group mb-2">
						<div class="input-group-prepend">
						  <div class="input-group-text">End Date</div>
						</div>
						<input id="demo4" name="enddate" type="text" name="enddate" size="25"><a href="javascript:NewCal('demo4','ddmmmyyyy',true,24)"><img src="cal.gif" width="16" height="16" border="0" alt="Pick a date"></a>
					  </div>
					</div>
					<div class="col-auto">
					  <input type="submit" class="btn btn-primary mb-2" name='submit' value='Get List'>
					</div>
				  </div>
				</form>
			</div>
		
	   </div>
       <div class='container-fluid'  style="padding-top:50px;">
	   <div class='col-lg-1'></div>
			<div class='col-lg-10'>
			   <div class="table-responsive">
				  <table class="table table-hover" style="white-space:nowrap;height:100% !important;" >
					  <thead>
						<tr>
						  <th scope="col">S.NO</th>
						  <th scope="col">Meeting Type</th>
						  <th scope="col">Start Date</th>
						  <th scope="col">End Date</th>
						  <th scope="col">Project</th>
						  <th scope="col">DU</th>
						  <th scope="col">VC Required</th>
						  <th scope="col">Requested By</th>
						  <th scope="col">Requested On</th>
						  <th scope="col">Status</th>
						</tr>
					  </thead>
					  <tbody>
						<?php 
							
							if(isset($_POST['submit'])){
								$startdate = $_POST['startdate'];
								$myArray = explode(' ',$startdate);
								$dup = explode('-',$myArray[0]);
								$m = date("m",strtotime($dup[1]));
								$dt1=$dup[2]."-".$m."-".$dup[0]." ".$myArray[1];
								
								$enddate = $_POST['enddate'];
								$myArray1 = explode(' ',$enddate);
								$dup1 = explode('-',$myArray1[0]);
								$m1 = date("m",strtotime($dup1[1]));
								$dt2=$dup1[2]."-".$m1."-".$dup1[0]." ".$myArray1[1];
								// echo "select * from tblactivities where start >= '$dt1' and end <= '$dt2'";
								$selectlist = mysqli_query($connect,"select * from tblactivities where start >= '$dt1' and end <= '$dt2'");
							$i = 1;
							while($getlist = mysqli_fetch_array($selectlist)){
						?>
							<tr>
							  <th><?php echo $i; ?></th>
							  <td><?php echo $getlist['title']; ?></td>
							  <td><?php echo $getlist['start']; ?></td>
							  <td><?php echo $getlist['end']; ?></td>
							  <td><?php echo $getlist['act_project']; ?></td>
							  <td><?php echo $getlist['act_du']; ?></td>
							  <td><?php echo $getlist['act_vcr']; ?></td>
							  <td><?php echo $getlist['act_req_by']; ?></td>
							  <td><?php echo $getlist['act_req_on']; ?></td>
							  <td><?php 
									$selectstatus = mysqli_query($connect,"select * from tblstatus where id=".$getlist['status']);
									$getstatus = mysqli_fetch_array($selectstatus);
									echo $getstatus['name']; 
									?>
							  </td>
							</tr>
							<?php 
								$i++;
								}
							}else{
								$selectlist = mysqli_query($connect,"select * from tblactivities");
								
							$i = 1;
							while($getlist = mysqli_fetch_array($selectlist)){
						?>
							<tr>
							  <th><?php echo $i; ?></th>
							  <td><?php echo $getlist['title']; ?></td>
							  <td><?php echo $getlist['start']; ?></td>
							  <td><?php echo $getlist['end']; ?></td>
							  <td><?php echo $getlist['act_project']; ?></td>
							  <td><?php echo $getlist['act_du']; ?></td>
							  <td><?php echo $getlist['act_vcr']; ?></td>
							  <td><?php echo $getlist['act_req_by']; ?></td>
							  <td><?php echo $getlist['act_req_on']; ?></td>
							  <td><?php 
									$selectstatus = mysqli_query($connect,"select * from tblstatus where id=".$getlist['status']);
									$getstatus = mysqli_fetch_array($selectstatus);
									echo $getstatus['name']; 
									?>
							  </td>
							</tr>
							<?php 
								$i++;
								}
							}
							?>
					   </tbody>
					</table>
				</div>
			</div>
		</div>
		
	   
                <!-- BEGIN QUICK SIDEBAR -->
                <a href="javascript:;" class="page-quick-sidebar-toggler">
                    <i class="icon-login"></i>
                </a>
        </div>        
                <!-- END QUICK SIDEBAR -->
            </div>
            <!-- END CONTAINER -->
            <!-- BEGIN FOOTER -->
            <?php //include "footer.php"; ?>
            <!-- END FOOTER -->
        </div>
        <!-- BEGIN QUICK NAV -->
        <!-- END QUICK NAV -->
        <?php //include "foot.php"; ?>
		<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
		
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
		<script src='datetimepicker.js'></script>
        <script src='fullcalendar/lib/moment.min.js'></script>
        <script src='fullcalendar/lib/jquery.min.js'></script>
        <script src='fullcalendar/fullcalendar.min.js'></script>
			<script type="text/javascript" src="//cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
		<script type="text/javascript" src="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.js"></script>
    </body>

</html>