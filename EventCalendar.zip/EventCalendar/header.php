<head>
    <link href='https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css' rel='stylesheet'/>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link href='fullcalendar/fullcalendar.min.css' rel='stylesheet' />
    <link href='fullcalendar/fullcalendar.print.min.css' rel='stylesheet' media='print' />
	
</head>
<style>

.fc-unthemed .fc-content, .fc-unthemed .fc-divider, .fc-unthemed .fc-list-heading td, .fc-unthemed .fc-list-view, .fc-unthemed .fc-popover, .fc-unthemed .fc-row, .fc-unthemed tbody, .fc-unthemed td, .fc-unthemed th, .fc-unthemed thead{
	border-color : #386077 !important;
}

#title{
	font-style: normal;
	background-color:#386077;
	font-size:40px;
	color:white;
	text-align:center;
	margin: auto;
}
.navbar-nav a{
	font-style: Arial, Helvetica, sans-serif;;
}
</style>


<div id="title"><b>BOARDROOM BOOKING</b><span style="float:right;padding-buttom:-20px;"><img src="images/css.png" alt="CSS CORP" style="height:55px;width:130px;-webkit-padding-after:10px !important;"/></span></div>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav" style="padding-left:13px;">
      <li class="nav-item active">
        <a class="nav-link" href="index.php"><b><button type="button" class="btn btn-primary">View Calendar</button> </b></a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="list.php"><b><button type="button" class="btn btn-primary">View List</button></b></a>
      </li>
	  
	</ul>
  </div>
</nav>