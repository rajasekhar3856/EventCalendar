<?php
error_reporting(0);
$connect=mysqli_connect("localhost","root","","event");
date_default_timezone_set('Asia/Kolkata');
?>